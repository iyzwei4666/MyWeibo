package com.popo.module_search.mvp.mvp.model;

public interface Api {
    String STEAM_DOMAIN_NAME="steam";
    String STEAM_DOMAIN="https://store.steampowered.com";

    String SANKO_DOMAIN="https://www.sonkwo.com/api/";
}
