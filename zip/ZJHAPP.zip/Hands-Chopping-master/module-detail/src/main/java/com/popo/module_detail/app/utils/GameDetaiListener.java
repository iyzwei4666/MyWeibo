package com.popo.module_detail.app.utils;

import com.popo.module_detail.mvp.model.entity.GameDetailBean;

public interface GameDetaiListener {
    void onGetted(String data);
}
