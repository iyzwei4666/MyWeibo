package com.popo.module_detail.app.utils;

public interface GetGameReviewListener {
    void onGetted(String s);
}
