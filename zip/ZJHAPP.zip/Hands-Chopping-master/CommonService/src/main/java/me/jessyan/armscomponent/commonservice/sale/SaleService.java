package me.jessyan.armscomponent.commonservice.sale;

import me.jessyan.armscomponent.commonservice.sale.bean.SaleList;

public interface SaleService {
    SaleList getSaleGameList();
}
