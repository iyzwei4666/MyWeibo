package com.popo.module_home.app.service;

import com.popo.module_home.mvp.model.entity.GameSaleList;
import com.popo.module_home.mvp.presenter.SalePresenter;

import me.jessyan.armscomponent.commonservice.sale.SaleService;
import me.jessyan.armscomponent.commonservice.sale.bean.SaleList;

public class SaleApi implements SaleService{
    @Override
    public SaleList getSaleGameList() {
        return null;
    }
}
